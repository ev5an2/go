package calc


func Sub(a int, b int) int {
	return a - b
}